function calculo() {
    var a = Number(document.getElementById("a").value)
    var b = Number(document.getElementById("b").value)
    var c = Number(document.getElementById("c").value)

    document.querySelector("#result").innerHTML = `A soma de ${a} + ${b} dividido por ${c} é igual a: ${(a+b/c)}`
}