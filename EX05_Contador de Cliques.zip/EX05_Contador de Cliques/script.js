var contador = 0
var res = document.querySelector("section#result")

function contar() {
    contador++
    res.innerHTML = `<p><span style="color: red;">Contagem:</span> ${contador}</p>`
}

function zerar() {
    contador = 0
    res.innerHTML = null
}