function calcular() {
    let num = Number(window.prompt("Digite um número:"));
    let res = document.querySelector("section#result")
    res.innerHTML = `<p>O número a ser analisado será o <strong>${num}</strong></p>`

    res.innerHTML += `<p>O seu valor absoluto é ${math.abs(num)}</p>`
    res.innerHTML += `<p>A sua parte inteira é ${math.trunc(num)}</p>`
    res.innerHTML += `<p>O valor mais próximo inteiro é ${math.round(num)}</p>`
    res.innerHTML += `<p>A sua raiz quadrada é ${math.sqrt(num)}</p>`
    res.innerHTML += `<p>A sua raiz cúbica é ${math.cbrt(num)}</p>`
    res.innerHTML += `<p>O valor de ${num} <sup>2</sup> é ${math.pow(nu,2)}</p>`
    res.innerHTML += `<p>O valor de ${num} <sup>3</sup> é ${math.pow(num, 3)}</p>`
}